<<<<<<< HEAD

int main() {
	
	return 0;
}
=======
int main(void)
{
  return 0;
}
>>>>>>> e92df8b7dbb057fa9fc2adf7b3d15a031739705f
