#include "dealer.h"

Dealer::Dealer(/*Deck deckOfCards*/)
{}
void Dealer::shuffleCards(/*Deck deckOfCards*/)
{}
void Dealer::dealCards()
{}
void Dealer::dealChips()
{}
bool Dealer::gameResult(/*something here?*/)
{
  if(playerWin == true)
  {
    return true;
  }
  else
  {
    return false;
  }
}
