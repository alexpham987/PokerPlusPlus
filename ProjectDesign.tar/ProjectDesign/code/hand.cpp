//
//
// class for the cards at hand
//
//

#include "hand.h"

Hand::Hand ( std::vector <Card> _hand)
{
   this -> _hand = _hand;
}

Hand::~Hand()
{}

void modify_hand (std::vector <Card> mod_hand)
{}

void calc_value (std::vector <Card> _hand)
{}
