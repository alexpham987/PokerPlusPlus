//
//
// class for player's stack, or their total chips
//
//

#include "stack.h"

void add_chips (int value_chips_added)
{}

void remove_chips (int value_chips_removed)
{}
