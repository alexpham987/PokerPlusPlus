#include "dealer.h"

Dealer::Dealer(bool playerResult) : _playerResult{playerResult}
{}
void Dealer::shuffleCards()
{}
void Dealer::dealCards()
{}
void Dealer::dealChips()
{}
bool Dealer::gameResult()
{
  return false;
}
void Dealer::exchangeCards(int amountOfCards)
{}
void Dealer::revealHand()
{}
void Dealer::playerJoin(Player player)
{}
void Dealer::playerLeave(Player player)
{}
void Dealer::deliverMessage(std::string message)
{}
